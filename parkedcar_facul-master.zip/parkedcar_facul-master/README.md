# parkedcar_facul
Projeto da faculdade - Desenvolvido em Python, flask com arquitetura MVC.
